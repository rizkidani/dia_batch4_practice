package com.ideaco.dia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
