package com.ideaco.dia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiaApplication.class, args);
	}

}
